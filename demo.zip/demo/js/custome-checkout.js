jQuery(document).ready(function($) {
    // Initially hide the payment section
    $('.woocommerce-checkout-payment').hide();
    
    // Toggle billing section
    $('#toggle-billing').on('click', function() {
        $('.woocommerce-billing-fields').toggle();
    });

    // Toggle payment section
    $('#toggle-payment').on('click', function() {
        $('.woocommerce-checkout-payment').toggle();
    });
});
