<?php get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <?php
        while ( have_posts() ) :
            the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                <?php 
                    // Display the featured image if it exists
                    if ( has_post_thumbnail() ) :
                        the_post_thumbnail('full'); // You can use 'thumbnail', 'medium', 'large', or 'full' as size
                    endif;
                    the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                </header>

                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </article>

            <?php
        endwhile;
        ?>

    </main>
</div>

<?php get_footer(); ?>
