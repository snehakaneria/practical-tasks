<?php
// Define arguments for the custom query
$args = array(
    'post_type'      => 'portfolio', // Custom post type
    'posts_per_page' => 3,           // Number of posts to display
    'orderby'       => 'date',       // Order by date
    'order'         => 'DESC'        // Latest posts first
);

// Create a new instance of WP_Query
$portfolio_query = new WP_Query( $args );

// Check if there are any posts to display
if ( $portfolio_query->have_posts() ) :
    ?>

    <div class="latest-portfolios">
        <?php
        // Start the loop to display posts
        while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php 
                    // Display the featured image if it exists
                    if ( has_post_thumbnail() ) :
                        the_post_thumbnail('medium'); // Adjust size as needed
                    endif;
                    ?>

                    <h2 class="entry-title">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h2>
                </header>

                <div class="entry-summary">
                    <?php the_content(); ?>
                </div>
            </article>

            <?php
        endwhile;
        ?>
    </div>

    <?php
else :
    // No posts found
    echo '<p>No portfolios found.</p>';
endif;

// Restore original Post Data
wp_reset_postdata();
?>
