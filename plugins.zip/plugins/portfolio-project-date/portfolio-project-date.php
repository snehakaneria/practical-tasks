<?php
/*
Plugin Name: Portfolio Project Date
Description: Adds a meta box to the Portfolio post type to capture the project date and displays it on the front end.
Version: 1.0
Author: Your Name
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Add meta box to 'Portfolio' post type
function ppd_add_meta_box() {
    add_meta_box(
        'ppd_project_date',
        __('Project Date', 'demo'),
        'ppd_meta_box_callback',
        'portfolio', // Post type
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'ppd_add_meta_box' );

// Display the meta box
function ppd_meta_box_callback( $post ) {
    // Retrieve existing value from the database
    $project_date = get_post_meta( $post->ID, '_ppd_project_date', true );
    ?>
    <label for="ppd_project_date"><?php _e('Project Date', 'demo'); ?></label>
    <input type="text" id="ppd_project_date" name="ppd_project_date" value="<?php echo esc_attr( $project_date ); ?>" />
    <?php
}

// Save meta box data
function ppd_save_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['ppd_project_date'] ) ) {
        return;
    }

    // Sanitize user input
    $project_date = sanitize_text_field( $_POST['ppd_project_date'] );

    // Update the meta field in the database
    update_post_meta( $post_id, '_ppd_project_date', $project_date );
}
add_action( 'save_post', 'ppd_save_meta_box_data' );

// Display project date on the front end
function ppd_display_project_date() {
    if ( is_singular('portfolio') ) {
        global $post;
        $project_date = get_post_meta( $post->ID, '_ppd_project_date', true );
        if ( $project_date ) {
            echo '<p><strong>' . __('Project Date:', 'demo') . '</strong> ' . esc_html( $project_date ) . '</p>';
        }
    }
}
add_action( 'the_content', 'ppd_display_project_date' );
